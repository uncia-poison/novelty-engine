# Novelty Engine v0.1

**Novelty Engine** is an experimental toolkit for refreshing the responses of large language models.  It detects stale phrasing and over‑used patterns and gently nudges rewrites without destroying the original facts or narrative voice.  The goal is not to rewrite everything, but to suppress clichés and encourage varied, lively form.

The project is split into two major stages:

* **Offline extraction**: we mine a corpus of conversations to collect *style etudes*, tiny pieces of form such as rhythm patterns or unusual syntactic turns.  These are stored in a JSONL database alongside embeddings and metadata.
* **Online linting and rewriting**: during inference we monitor the last few turns of a session to estimate “soapiness” – how repetitive or formulaic the current answer is.  If it drifts into sameness we look up suitable etudes and build a *rewrite plan* under a set of locks.  The actual rewriting can be performed by your own LLM or by a simple text‑editing model.

This repository does **not** depend on any proprietary LLM and can be used with online APIs, local models, or as a source of data for optional fine‑tuning.  You can integrate the linter and plan builder with your favourite chat model, or run the offline extractor to curate your own style library.

## Key Concepts

### Style etudes

Style etudes are small patterns of form extracted from your own data.  They do not contain complete sentences; rather, they describe syntactic shapes, rhythm signatures or unusual collocations.  We avoid copying any lexical content into responses.  At runtime these etudes serve as **hints** to push a rewrite in a fresh direction.

Each etude record includes:

* A unique identifier
* One or more types (`syntactic`, `rhythm`, `lexical`)
* The abstract pattern (e.g. `short.short.long` + dash insertion)
* An embedding for semantic filtering
* Novelty scores from the extraction process
* Optional domain tags

See `dreamspace/extract_etudes.py` for the extraction pipeline and the output schema.

### Linter with metric gating

The linter sits in your inference loop and maintains a sliding window of the most recent utterances (e.g. 12 turns).  It computes several metrics:

* **n‑gram repetition** – how often the same short phrases reappear
* **token distribution KL divergence** – how collapsed the distribution is compared to the session average
* **gesture repetition** – how often the same syntactic patterns recur
* **cliché hits** – matches to a configurable list of banned phrases

These metrics are combined into a single *soapiness* score.  If it exceeds a threshold and the current domain allows intervention, the linter selects one or two relevant etudes (respecting cool‑downs and semantic similarity) and produces a plan.

### Rewrite plan under locks

Instead of blindly rewriting, we produce a structured plan that tells the next component *what* to do.  A plan includes:

* **locks** – facts that must not change (numbers, named entities, quotations)
* **remove** – specific clichés or tautologies to delete
* **inject** – one or more etude patterns to be used as a formal guide
* **max_edit_ratio** – the maximum percentage of tokens that may be altered
* **style constraints** – optional knobs for voice weight and generation temperature

Your rewriting model receives the original draft along with this plan and is expected to produce a minimally edited, freshened version that respects all locks.  After generation a fact guard compares numbers, dates and named entities to ensure nothing was lost or invented.

## Repository Layout

```
novelty-engine/
├── dreamspace/
│   ├── extract_etudes.py        # extract and score style etudes from dialogs
│   ├── build_dict.py            # assemble a style dictionary from extracted etudes
│   ├── etudes.jsonl             # example output (not committed by default)
├── linter/
│   ├── lint.py                  # compute soapiness and select etudes
│   ├── cliches.txt              # list of banned phrases and patterns
│   ├── cooldowns.json           # cool‑down configuration for patterns
│   ├── plan_schema.json         # JSON schema describing the rewrite plan format
├── rewriter/
│   ├── rewrite.py               # apply the plan using your model or a simple editor
│   ├── fact_locks.py            # extract and check immutable facts
├── eval/
│   ├── auto_metrics.py          # scripts to compute diversity and voice scores
│   └── examples/                # sample A/B evaluation setups
├── policy/
│   ├── router.py                # determine whether to intervene based on domain
│   └── domains.yml              # domain configuration (full, rhythm_only, off)
├── scoring/
│   ├── voice_clf/               # placeholder for a trained voice classifier
├── tests/
│   ├── test_extract.py          # unit tests for the extractor
│   ├── test_lint.py             # unit tests for the linter
│   └── test_rewrite.py          # unit tests for the rewriting logic
└── data/
    └── dialogs/                # your raw conversations (not included in repo)
```

Empty directories are kept in version control using `.gitkeep` files.

## Usage

### Offline extraction

Provide a directory of raw conversations as JSONL, with fields such as `conv_id`, `turn_id`, `speaker` and `text`.  Run:

```bash
python3 -m novelty_engine.dreamspace.extract_etudes --input=data/dialogs --output=novelty-engine/dreamspace/etudes.jsonl
```

This script tokenises, computes novelty heuristics (e.g. TF–IDF spikes, PMI to domain cores), groups similar patterns and writes out a set of candidate etudes.  Afterwards you can build a style dictionary with `build_dict.py` or curate the JSONL manually.

### Integrating the linter

The linter can be wrapped around any chat pipeline.  At each draft response you call:

```python
from novelty_engine.linter import lint
from novelty_engine.rewriter import rewrite

plan = lint.inspect(draft, context)
if plan.mode == "micro":
    refreshed = rewrite.apply_plan(draft, plan, your_model)
else:
    refreshed = draft  # no intervention
```

`lint.inspect` returns a plan only when intervention is warranted; otherwise it returns a minimal plan.  You can plug in your own metric thresholds and pattern libraries via configuration files.  See `cliches.txt` and `cooldowns.json` for examples.

### Manual and online use

You can also apply the linter and rewriter manually with online models.  For example, pass your chat response through `lint.inspect`, read the resulting plan, and then instruct an API model to rewrite the text accordingly.  This approach works even when you do not control the model internals, because all rewrites are performed via prompting rather than logit manipulation.

### Local models and fine‑tuning

If you run your own local model you can integrate deeper.  The repository includes hooks to apply logit penalties for clichés and gentle boosts for etude patterns during decoding (see `scoring/`).  You can also use the extracted etudes and rewrite pairs as training data for a small preference model or a LoRA head.  The pipeline is modular: start with the external linter/rewriter and upgrade gradually.

## Roadmap

1. Implement a light‑weight voice classifier for monitoring stylistic drift.
2. Add a semantic similarity filter to avoid injecting irrelevant etudes.
3. Provide sample datasets and evaluation harness for community benchmarks.
4. Explore constrained decoding techniques to enforce locks at the logit level.

Contributions and feedback are welcome.  Please open an issue or pull request with ideas and improvements.