The `scoring` directory holds auxiliary models and scripts used for
automatic assessment of generated responses.  In particular you may
place a trained voice classifier under `voice_clf/` or store IDF
statistics used by your novelty extractor.  These assets are not
committed by default.